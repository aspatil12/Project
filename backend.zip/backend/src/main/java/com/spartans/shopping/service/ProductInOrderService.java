package com.spartans.shopping.service;

import com.spartans.shopping.entity.ProductInOrder;
import com.spartans.shopping.entity.User;

/**
 * Created By Zhu Lin on 1/3/2019.
 */
public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
